import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-collection-page',
  templateUrl: './collection-page.component.html',
  styleUrls: ['./collection-page.component.scss']
})
export class CollectionPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
