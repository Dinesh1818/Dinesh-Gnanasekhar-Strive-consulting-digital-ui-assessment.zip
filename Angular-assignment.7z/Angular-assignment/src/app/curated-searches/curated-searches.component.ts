import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-curated-searches',
  templateUrl: './curated-searches.component.html',
  styleUrls: ['./curated-searches.component.scss']
})
export class CuratedSearchesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
